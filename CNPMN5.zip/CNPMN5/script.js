document.addEventListener("DOMContentLoaded", () => {
    updateCartCount();
    setupCartButtons();
    setupCheckoutForm();

    if (document.getElementById("cart-items")) {
        displayCart();
    }
});

//  Cập nhật số lượng sản phẩm trong giỏ hàng
function updateCartCount() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.getElementById("cart-count").textContent = totalCount;
}

//  Thêm sản phẩm vào giỏ hàng
function setupCartButtons() {
    document.querySelectorAll(".add-to-cart").forEach(button => {
        button.addEventListener("click", (event) => {
            let product = event.target.closest(".product");
            let productId = product.dataset.id;
            let productName = product.dataset.name;
            let productPrice = parseInt(product.dataset.price);

            let cart = JSON.parse(localStorage.getItem("cart")) || [];
            let existingItem = cart.find(item => item.id === productId);

            if (existingItem) {
                existingItem.quantity++;
            } else {
                cart.push({ id: productId, name: productName, price: productPrice, quantity: 1 });
            }

            localStorage.setItem("cart", JSON.stringify(cart));
            updateCartCount();
        });
    });
}

// 🛒 Hiển thị giỏ hàng
function displayCart() {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    let cartContainer = document.getElementById("cart-items");
    cartContainer.innerHTML = "";

    cart.forEach(item => {
        let div = document.createElement("div");
        div.textContent = `${item.name} - ${item.quantity} x ${item.price.toLocaleString()}đ`;
        cartContainer.appendChild(div);
    });

    let total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    document.getElementById("cart-total").textContent = total.toLocaleString();
}

//  Xóa giỏ hàng
function clearCart() {
    localStorage.removeItem("cart");
    window.location.href = "index.html";
}

//  Xử lý thanh toán
function setupCheckoutForm() {
    let checkoutForm = document.getElementById("checkout-form");

    if (checkoutForm) {
        checkoutForm.addEventListener("submit", (event) => {
            event.preventDefault();
            
            let name = document.getElementById("name").value.trim();
            let address = document.getElementById("address").value.trim();
            let cart = JSON.parse(localStorage.getItem("cart")) || [];

            if (!name || !address || cart.length === 0) {
                alert("Vui lòng nhập đầy đủ thông tin và đảm bảo giỏ hàng không trống.");
                return;
            }

            let orderDetails = `Tên: ${name}, Địa chỉ: ${address}, Sản phẩm: ${JSON.stringify(cart)}`;

            fetch(`/log-order?data=${encodeURIComponent(orderDetails)}`, { method: "GET" })
                .then(() => {
                    alert("Đơn hàng của bạn đã được ghi lại!");
                    localStorage.removeItem("cart");
                    window.location.href = "index.html";
                })
                .catch(() => alert("Lỗi khi ghi đơn hàng."));
        });
    }
}
